import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Menu, Plus, Coffee, ChevronDown } from 'lucide-react';
import { getDeviceId, getCredits, getSessions, getHistory, deleteSession, streamChat } from './api';
import { tx } from './i18n';
import { Logo } from './components/Logo';
import { Splash } from './components/Splash';
import { LanguageSelect } from './components/LanguageSelect';
import { MessageList } from './components/MessageList';
import { Composer } from './components/Composer';
import { HistoryDrawer } from './components/HistoryDrawer';
import { SettingsSheet } from './components/SettingsSheet';
import { Toast } from './components/Toast';

function statusMessage(status, lang) {
  if (status===402) return tx(lang,'outOfCredits');
  if (status===403) return tx(lang,'restricted');
  if (status===429) return tx(lang,'tooFast');
  if (status===503) return tx(lang,'busy');
  return tx(lang,'wrong');
}

export function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [lang, setLang] = useState(() => localStorage.getItem('bondhu_lang') || null);
  const [dark, setDark] = useState(() => localStorage.getItem('bondhu_dark') === '1');
  const [deviceId] = useState(getDeviceId);
  const [credits, setCredits] = useState(null);
  const [banned, setBanned] = useState(false);
  const [sessions, setSessions] = useState([]);
  const [currentSessionId, setCurrentSessionId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [streaming, setStreaming] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const [settings, setSettings] = useState(false);
  const [toast, setToast] = useState('');
  const abortRef = useRef(null);
  const currentUserPrompt = useRef('');

  useEffect(() => { document.documentElement.classList.toggle('dark', dark); localStorage.setItem('bondhu_dark', dark?'1':'0'); }, [dark]);
  useEffect(() => {
    const updateViewport = () => {
      const h = window.visualViewport?.height || window.innerHeight;
      document.documentElement.style.setProperty('--vvh', `${h}px`);
    };
    updateViewport();
    window.visualViewport?.addEventListener('resize', updateViewport);
    window.visualViewport?.addEventListener('scroll', updateViewport);
    window.addEventListener('resize', updateViewport);
    return () => {
      window.visualViewport?.removeEventListener('resize', updateViewport);
      window.visualViewport?.removeEventListener('scroll', updateViewport);
      window.removeEventListener('resize', updateViewport);
    };
  }, []);
  useEffect(() => { if (lang) localStorage.setItem('bondhu_lang', lang); }, [lang]);

  const refreshData = useCallback(async () => {
    try { const c = await getCredits(deviceId); setCredits(c.remaining_credits); setBanned(Boolean(c.banned)); } catch { setToast(tx(lang||'bn','wrong')); }
    try { setSessions(await getSessions(deviceId)); } catch {}
  }, [deviceId, lang]);

  useEffect(() => { if (!showSplash && lang) refreshData(); }, [showSplash, lang, refreshData]);

  const showToast = useCallback((m) => setToast(m), []);

  const copyText = useCallback(async (text) => { try { await navigator.clipboard.writeText(text); setToast(tx(lang,'copied')); } catch {} }, [lang]);

  const shareApp = useCallback(async () => {
    const payload = { title: 'Bondhu AI', text: tx(lang,'shareText'), url: location.origin };
    try { if (navigator.share) { await navigator.share(payload); setToast(tx(lang,'shared')); } else { await navigator.clipboard.writeText(location.origin); setToast(tx(lang,'shareCopied')); } } catch {}
  }, [lang]);

  const newChat = useCallback(() => { abortRef.current?.abort(); setStreaming(false); setCurrentSessionId(null); setMessages([]); setInput(''); setDrawer(false); }, []);

  const openSession = useCallback(async (id) => {
    try {
      const history = await getHistory(deviceId, id);
      setMessages(history.map((m,i)=>({ id:`old-${i}-${m.created_at||''}`, role:m.role, content:m.content })));
      setCurrentSessionId(id);
      setDrawer(false);
    } catch { setToast(tx(lang,'wrong')); }
  }, [deviceId, lang]);

  const removeSession = useCallback(async (s) => {
    if (!window.confirm(tx(lang,'deleteConfirm'))) return;
    try { await deleteSession(deviceId, s.id); if (currentSessionId===s.id) newChat(); setSessions(v=>v.filter(x=>x.id!==s.id)); } catch { setToast(tx(lang,'wrong')); }
  }, [deviceId, currentSessionId, lang, newChat]);

  const sendMessage = useCallback(async (forcedText) => {
    if (streaming) return;
    const text = (forcedText ?? input).trim();
    if (!text) return;
    if (text.length > 4000) { setToast(tx(lang,'messageTooLong')); return; }
    if (credits === 0) { setToast(tx(lang,'outOfCredits')); return; }
    currentUserPrompt.current = text;
    setInput('');
    const userMsg = { id: crypto.randomUUID(), role:'user', content:text };
    const aiId = crypto.randomUUID();
    setMessages(v => [...v, userMsg, { id:aiId, role:'assistant', content:'', streaming:true }]);
    setStreaming(true);
    const controller = new AbortController(); abortRef.current = controller;
    let gotDelta = false;
    try {
      await streamChat({ deviceId, message:text, sessionId:currentSessionId, signal:controller.signal, onEvent:(name,data)=>{
        if (name==='meta') { if (data.session_id) setCurrentSessionId(data.session_id); if (typeof data.remaining_credits==='number') setCredits(data.remaining_credits); }
        else if (name==='delta') { gotDelta = true; setMessages(v=>v.map(m=>m.id===aiId?{...m,content:m.content+(data.text||''),streaming:true}:m)); }
        else if (name==='done') { setCurrentSessionId(data.session_id || currentSessionId); if (typeof data.remaining_credits==='number') setCredits(data.remaining_credits); setMessages(v=>v.map(m=>m.id===aiId?{...m,content:data.reply || m.content,streaming:false}:m)); }
        else if (name==='error') { setMessages(v=>v.map(m=>m.id===aiId?{...m,content:data.error||tx(lang,'wrong'),streaming:false,role:'error'}:m)); }
      }});
      setMessages(v=>v.map(m=>m.id===aiId?{...m,streaming:false}:m));
      await refreshData();
    } catch (err) {
      if (err?.name === 'AbortError') { setMessages(v=>v.map(m=>m.id===aiId?{...m,streaming:false,content:m.content || 'Stopped.'}:m)); }
      else if (!gotDelta) { setMessages(v=>v.map(m=>m.id===aiId?{...m,role:'error',streaming:false,content:statusMessage(err.status,lang)}:m)); }
      else { setMessages(v=>v.map(m=>m.id===aiId?{...m,streaming:false,interrupted:true,retry:true}:m)); }
    } finally { setStreaming(false); abortRef.current=null; }
  }, [streaming, input, lang, credits, deviceId, currentSessionId, refreshData]);

  const retryMessage = useCallback((m) => { if (!m?.id) return; const idx = messages.findIndex(x=>x.id===m.id); const user = messages.slice(0,idx).reverse().find(x=>x.role==='user'); if (user) sendMessage(user.content); }, [messages, sendMessage]);

  if (showSplash) return <Splash onDone={()=>setShowSplash(false)} />;
  if (!lang) return <LanguageSelect onSelect={v=>{setLang(v);setToast(tx(v,'invited'));}} />;
  if (banned) return <div className="min-h-screen bg-stone-50 p-6 dark:bg-[#0E1512]"><div className="mx-auto mt-20 max-w-md rounded-3xl bg-white p-7 text-center shadow-soft dark:bg-[#171F1B]"><Logo /><h1 className="mt-7 text-xl font-extrabold dark:text-white">{tx(lang,'restricted')}</h1><p className="mt-2 text-sm text-slate-500">{tx(lang,'restrictedHint')}</p></div><Toast message={toast} onDone={()=>setToast('')} /></div>;

  const suggestions = tx(lang,'suggestions');
  return <div className="app-shell flex min-h-screen flex-col bg-[#F7F7F5] text-slate-900 dark:bg-[#0E1512] dark:text-[#E8F0EC]">
    <header className="sticky top-0 z-30 border-b border-[#E5E5E0]/80 bg-[#F7F7F5]/90 backdrop-blur dark:border-[#243029]/80 dark:bg-[#0E1512]/90">
      <div className="mx-auto flex h-16 max-w-3xl items-center justify-between px-3 sm:px-5">
        <button aria-label="Open chat history" onClick={()=>setDrawer(true)} className="rounded-xl p-2.5 hover:bg-slate-100 dark:hover:bg-white/5"><Menu className="h-5 w-5" /></button>
        <div className="absolute left-1/2 -translate-x-1/2"><Logo compact /></div>
        <div className="flex items-center gap-1.5"><div className="hidden rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-bold text-bengal dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300 sm:block">💳 {credits ?? '—'}</div><button aria-label={tx(lang,'newChat')} onClick={newChat} className="rounded-xl p-2.5 hover:bg-slate-100 dark:hover:bg-white/5"><Plus className="h-5 w-5" /></button></div>
      </div>
      <div className="mx-auto block max-w-3xl px-3 pb-2 sm:hidden"><div className="w-fit rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-[11px] font-bold text-bengal dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300">💳 {credits ?? '—'}</div></div>
    </header>

    {messages.length === 0 ? <main className="flex flex-1 items-center justify-center px-4 py-10 sm:py-14"><div className="w-full max-w-2xl text-center"><div className="greeting text-balance text-3xl font-black tracking-tight sm:text-4xl">{tx(lang,'welcome').split(/\s+/).map((w,i)=><span key={i} className="mr-2 inline-block animate-word">{w}</span>)}</div><p className="mx-auto mt-5 max-w-lg text-sm leading-6 text-slate-500 dark:text-slate-300">{lang==='bn'?'বাংলা, English বা Banglish—যেভাবে স্বচ্ছন্দ, সেভাবেই কথা বলুন।':'Talk in Bangla, English, or Banglish—whichever feels natural.'}</p><div className="mt-7 grid gap-2 sm:grid-cols-2">{suggestions.map(s=><button key={s} onClick={()=>setInput(s)} className="rounded-2xl border border-[#E5E5E0] bg-white px-4 py-3 text-left text-sm font-medium shadow-soft transition hover:-translate-y-0.5 hover:border-emerald-300 dark:border-[#243029] dark:bg-[#171F1B]">{s}</button>)}</div></div></main>
    : <MessageList messages={messages} lang={lang} onCopy={copyText} onRetry={retryMessage} streaming={streaming} />}

    {streaming && messages.length > 0 && messages.at(-1)?.content === '' && <div className="pointer-events-none px-5 pb-1"><div className="mx-auto flex max-w-3xl items-center gap-2 text-xs text-slate-500"><Coffee className="h-3.5 w-3.5" />{messages.length<=2?tx(lang,'waking'):tx(lang,'typing')}<span className="ml-1 animate-pulse">•••</span></div></div>}
    <Composer value={input} onChange={setInput} onSend={()=>sendMessage()} onStop={()=>abortRef.current?.abort()} disabled={streaming} streaming={streaming} lang={lang} onToast={showToast} />

    <HistoryDrawer open={drawer} sessions={sessions} currentId={currentSessionId} lang={lang} onClose={()=>setDrawer(false)} onNew={newChat} onOpen={openSession} onDelete={removeSession} onSettings={()=>{setDrawer(false);setSettings(true)}} />
    <SettingsSheet open={settings} onClose={()=>setSettings(false)} lang={lang} setLang={setLang} dark={dark} setDark={setDark} credits={credits} onShare={shareApp} />
    <Toast message={toast} onDone={()=>setToast('')} />
  </div>;
}
