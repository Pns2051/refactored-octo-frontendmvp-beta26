export const API_BASE = import.meta.env.VITE_API_BASE_URL || 'https://bondhu-ai-backed-beta26.onrender.com';

export function getDeviceId() {
  const key = 'bondhu_device_id';
  let id = localStorage.getItem(key);
  if (!id) {
    id = `web-${crypto.randomUUID()}`;
    localStorage.setItem(key, id);
  }
  return id;
}

async function readJson(response) {
  const text = await response.text();
  try { return JSON.parse(text); } catch { return {}; }
}

export async function getCredits(deviceId) {
  const res = await fetch(`${API_BASE}/api/credits?device_id=${encodeURIComponent(deviceId)}`);
  const data = await readJson(res);
  if (!res.ok) throw Object.assign(new Error(data.error || 'credits_failed'), { status: res.status, data });
  return data;
}

export async function getSessions(deviceId) {
  const res = await fetch(`${API_BASE}/api/sessions?device_id=${encodeURIComponent(deviceId)}`);
  const data = await readJson(res);
  if (!res.ok) throw Object.assign(new Error(data.error || 'sessions_failed'), { status: res.status, data });
  return data.sessions || [];
}

export async function getHistory(deviceId, sessionId) {
  const url = `${API_BASE}/api/history?device_id=${encodeURIComponent(deviceId)}&session_id=${encodeURIComponent(sessionId)}`;
  const res = await fetch(url);
  const data = await readJson(res);
  if (!res.ok) throw Object.assign(new Error(data.error || 'history_failed'), { status: res.status, data });
  return data.messages || [];
}

export async function deleteSession(deviceId, sessionId) {
  const url = `${API_BASE}/api/sessions/${encodeURIComponent(sessionId)}?device_id=${encodeURIComponent(deviceId)}`;
  const res = await fetch(url, { method: 'DELETE' });
  const data = await readJson(res);
  if (!res.ok) throw Object.assign(new Error(data.error || 'delete_failed'), { status: res.status, data });
  return data;
}

export async function streamChat({ deviceId, message, sessionId, signal, onEvent }) {
  const body = { device_id: deviceId, message };
  if (sessionId) body.session_id = sessionId;

  const res = await fetch(`${API_BASE}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Accept': 'text/event-stream' },
    body: JSON.stringify(body),
    signal
  });

  if (!res.ok) {
    const data = await readJson(res);
    const err = new Error(data.error || `HTTP ${res.status}`);
    err.status = res.status;
    err.data = data;
    throw err;
  }
  if (!res.body) throw new Error('stream_unavailable');

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  const dispatchFrame = (frame) => {
    if (!frame.trim()) return;
    let eventName = 'message';
    let dataLine = '';
    for (const line of frame.split(/\r?\n/)) {
      if (line.startsWith(':')) continue;
      if (line.startsWith('event:')) eventName = line.slice(6).trim();
      if (line.startsWith('data:')) dataLine += line.slice(5).trim();
    }
    if (!dataLine) return;
    try {
      onEvent(eventName, JSON.parse(dataLine));
    } catch {
      onEvent('error', { error: 'Malformed server event' });
    }
  };

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const frames = buffer.split(/\r?\n\r?\n/);
    buffer = frames.pop() || '';
    frames.forEach(dispatchFrame);
  }
  buffer += decoder.decode();
  if (buffer.trim()) dispatchFrame(buffer);
}
